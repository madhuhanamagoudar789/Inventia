import React from "react";
import styles from "./styles.module.scss";

const TeamCard = ({ name, role, imgLeft, image, ...rest }) => {
  const cardClass = imgLeft ? styles.card_imgLeft : styles.card_imgRight;

  return (
    <div className={`${styles.teamCard} ${cardClass}`} {...rest}>
      <img src={image} alt={`${name}`} className={styles.teamImage} />
      <div className={styles.teamContent}>
        <h3>{name}</h3>
        <p>{role}</p>
      </div>
    </div>
  );
};

export default TeamCard;
