import React from "react";
import Homepage from "./container/Homepage";
import "./App.css";
const App = () => {
  return (
    <div>
      <Homepage />
    </div>
  );
};

export default App;
