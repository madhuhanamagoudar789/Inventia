import Logo from "./Logo.svg";
import LineSeperator from "./Line separator (2).svg";
import ArrorUp from "./ArrowUp.svg";
import Frame from "./Frame.svg";
import ArrowUpRight from "./ArrowUpRight.svg";
import card1Img from "./inv_icons_expertR&D 1.svg";
import card2Img from "./inv_icons_globalaccess 1.svg";
import card3Img from "./inv_icons_flexmodel 1.svg";
import card4Img from "./inv_icons_collaboration 1.svg";
import CaretLeft from "./CaretLeft.svg";
import CaretRight from "./CaretRight.svg";
import Microscope from "./microscope.png";
import Building from "./building.png";
import Lab from "./lab.png";
import PartnerImg1 from "./partnerImg1.svg";
import PartnerImg2 from "./partnerImg2.svg";
import PartnerImg3 from "./partnerImg3.svg";
import PartnerImg4 from "./partnerImg4.svg";
import PartnerImg5 from "./partnerImg5.svg";
import PartnerImg6 from "./partnerImg6.svg";
import PartnerImg7 from "./partnerImg7.svg";
import PartnerImg8 from "./partnerImg8.svg";
import PartnerImg9 from "./partnerImg9.svg";
import PartnerImg10 from "./partnerImg10.png";
import DiscoverImg from "./discoverImg.png";
import Twitter from "./TwitterLogo.svg";
import Instagram from "./InstagramLogo.svg";
import Facebook from "./FacebookLogo.svg";
import Linkedin from "./LinkedinLogo.svg";
import JanakImage from "./JanakImage.png";
import NareshImage from "./NareshImage.png";
import VaibhaviImage from "./VaibhaviImage.png";
import HemendraImage from "./HemendraImage.png";
import MayaImage from "./MayaImage.png";
export {
  Logo,
  LineSeperator,
  ArrorUp,
  Frame,
  ArrowUpRight,
  card1Img,
  card2Img,
  card3Img,
  card4Img,
  CaretLeft,
  CaretRight,
  Microscope,
  Building,
  Lab,
  PartnerImg1,
  PartnerImg2,
  PartnerImg3,
  PartnerImg4,
  PartnerImg5,
  PartnerImg6,
  PartnerImg7,
  PartnerImg8,
  PartnerImg9,
  PartnerImg10,
  DiscoverImg,
  Twitter,
  Instagram,
  Facebook,
  Linkedin,
  JanakImage,
  NareshImage,
  VaibhaviImage,
  HemendraImage,
  MayaImage,
};
